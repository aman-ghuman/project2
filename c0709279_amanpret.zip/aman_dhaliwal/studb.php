<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";
// Create connection
$conn = new mysqli($servername, $username, $password , $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


/*// Create database
$sql = "CREATE DATABASE Library";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}*/

// use database
$sql = "USE Library";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}



//sql to create table
$sql = "CREATE TABLE Student_Master (
student_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
student_Name VARCHAR(50) NOT NULL,
Gender VARCHAR(50) NOT NULL,
Address VARCHAR(50),
City VARCHAR(50),
Province VARCHAR(50),
Postalcode VARCHAR(50)
)";
if ($conn->query($sql) === TRUE) {
    echo "Table student_Master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
//sql to create table
$sql = "CREATE TABLE library_user_master (
user_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,

password VARCHAR(50) NOT NULL,
Account_creation_date VARCHAR(228) NOT NULL
)";




if ($conn->query($sql) === TRUE) {
    echo "Table library_user_master_Master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}




$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('1','lovepreet','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";

$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('2','veerpal','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";

$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('3','aman','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";

$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('4','bikram','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";

$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('5','amit','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";

$sql = "INSERT INTO student_Master(student_id,student_Name,Gender,Address,City,Province,Postalcode)
VALUES('6','lovey','Female','15 paleshi drive','toronto','Ontario','L6P2C3')";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('1','12345',2017/1/4)";

/*$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('2','12345',2017/1/4)";

/*$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('3','2345',2017/1/4)";

/*$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('4','1234',2017/1/4)";

/*$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('5','123456',2017/1/4)";

/*$sql = "INSERT INTO library_user_master(user_id,password,Account_creation_date)
VALUES('6','1234567',2017/1/4)";*/

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>