 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Library";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
//$retval = mysql_query( $sql, $conn );
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";





/*// Create database
$sql = "CREATE DATABASE Library";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}*/


// use database
$sql = "USE Library";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}


 //sql to create table
$sql = "CREATE TABLE Admin_Master (
Admin_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Admin_Name VARCHAR(50) NOT NULL,
Gender VARCHAR(50) NOT NULL,
Address VARCHAR(50),
City VARCHAR(50),
Province VARCHAR(50),
Postalcode VARCHAR(50),
JoiningDate TIMESTAMP
)";




if ($conn->query($sql) === TRUE) {
    echo "Table Admin_Master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
//sql to create table
$sql = "CREATE TABLE Book_Master1 (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Book_title VARCHAR(50) NOT NULL,
Author VARCHAR(50) NOT NULL,
Publisher VARCHAR(50),
Edition VARCHAR(50),
ISBN_No VARCHAR(50),
price VARCHAR(50),
Total_no_of_copies VARCHAR(50)
)";




if ($conn->query($sql) === TRUE) {
    echo "Table Book_Master1 created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


//sql to create table
$sql = "CREATE TABLE Student_Master (
student_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
student_Name VARCHAR(50) NOT NULL,
Gender VARCHAR(50) NOT NULL,
Address VARCHAR(50),
City VARCHAR(50),
Province VARCHAR(50),
Postalcode VARCHAR(50)
)";




if ($conn->query($sql) === TRUE) {
    echo "Table student_Master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

//sql to create table
$sql = "CREATE TABLE library_user_master (
user_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
password VARCHAR(50) NOT NULL,
Account_creation_date TIMESTAMP
)";




if ($conn->query($sql) === TRUE) {
    echo "Table library_user_master_Master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

//sql to create table
$sql = "CREATE TABLE return_master (
book_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
student_id INT(6),
from_date TIMESTAMP,
to_date TIMESTAMP,
description VARCHAR(50)
)";




if ($conn->query($sql) === TRUE) {
    echo "Table return_master created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

//INSERTION INTO TABLE ADMIN_MASTER;

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('1','raman','Female','15 paleshi drive','toronto','Ontario','L6P2C3' ,'2016/09/15')";

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('2','lovepreet','Female','45 paleshi drive','toronto','Ontario','L6P2C3' ,'2016/22/15')";

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('3','veerpal','Female','30 paleshi drive','toronto','Ontario','L6P2C3' ,'2016/4/15')";

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('4','aman','Female','19 paleshi drive','toronto','Ontario','L6P2C3' ,'2016/06/15')";

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('5','vipan','Female','17 paleshi drive','toronto','Ontario','L6P2C3' ,'2016/15/15')";

$sql = "INSERT INTO Admin_Master(Admin_id,Admin_Name,Gender,Address,City,Province,Postalcode,JoiningDate)
VALUES('6','kiran','Female','17 academy drive','scarbrough','Ontario','L6k2C3' ,'2016/15/15')";


//INSERTION INTO TABLE Book_Master1;

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('1','PHP','j.k.rowling','pearson','1994','222','$120' ,'4')";

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('2','java','mark twain','random house','1992','565','$130' ,'6')";

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('3','MySql','stephen king','groupo planeta','2000','675','$170' ,'3')";

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('7','RDBMS','jane austin','wiley','2004','343','$180' ,'7')";

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('5','Intro to Android','C.S.Lewis','cengage','2007','777','$100' ,'9')";

$sql = "INSERT INTO book_Master1(id,Book_title,Author,Publisher,Edition,ISBN_No,Price,Total_no_of_copies)
VALUES('6','c++','Leo Tolstoy','informa','2014','223','$200' ,'5')";




//INSERTION INTO TABLE RETURN_MASTER;
$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('3','5','2017/04/12','2017/05/16','return book')";

$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('4','7','2017/05/18','2017/05/16','issue book')";

$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('9','5','2017/05/14','2017/05/18','return book')";

$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('11','9','2017/06/18','2017/05/18','issue book')";


$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('13','12','2017/07/17','2017/07/18','issue book')";


$sql = "INSERT INTO return_master(book_id,student_id,from_date,to_date,description)
VALUES('15','13','2017/07/18','2017/07/20','issue book')";







if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$conn->close();
?>